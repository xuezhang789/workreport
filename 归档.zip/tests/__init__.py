# Mark tests as a package for Django test discovery.
